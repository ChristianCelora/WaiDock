/* begin_generated_IBM_copyright_prolog                             */
/*                                                                  */
/* This is an automatically generated copyright prolog.             */
/* After initializing,  DO NOT MODIFY OR MOVE                       */
/* ---------------------------------------------------------------- */
/* IBM Confidential                                                 */
/*                                                                  */
/* OCO Source Materials                                             */
/*                                                                  */
/* Product(s):                                                      */
/*     5722-XE1                                                     */
/*                                                                  */
/* (C)Copyright IBM Corp.  1995, 2005                               */
/*                                                                  */
/* The Source code for this program is not published  or otherwise  */
/* divested of its trade secrets,  irrespective of what has been    */
/* deposited with the U.S. Copyright Office.                        */
/*  --------------------------------------------------------------- */
/*                                                                  */
/* end_generated_IBM_copyright_prolog                               */

/********************************************************************/
/*                                                                  */
/* Module:                                                          */
/*   CWBXA.H                                                        */
/*                                                                  */
/* Purpose:                                                         */
/*   The functions listed in this file can be used for              */
/*   Open/XA implementations using iSeries Access.                  */
/*                                                                  */
/* Usage Notes:                                                     */
/*   Link with CWBAPI.LIB import library.                           */
/*   This module is to be used in conjunction with CWBCORE.DLL.     */
/*                                                                  */
/*   These APIs can be used by an ODBC or OLE DB application to     */
/*   access the iSeries database server XA interface.               */
/*                                                                  */
/*   The normal usage from ODBC or oleDB would be to first make a   */
/*   call to cwbXA_AddRMID to register your RMID/System object      */
/*   pair. The caller is responsible to "makeup" a process wide     */
/*   unique RMID that represents this this connection. In V5R2,     */
/*   ODBC just  uses the current connection object pointer for this */
/*   value. You can also cwbXA_AddRMID to update an existing        */
/*   rmid's timeout options.                                        */
/*                                                                  */
/*   A matching call to cwbCO_DeleteRMID is required when the       */
/*   caller is done with this RMID.                                 */
/*                                                                  */
/*   After the RMID is registered, the caller can make any of the   */
/*   cwbXA_xxxx calls using that RMID.                              */
/*   Open and Close are unique and are usually ONLY called during   */
/*   the actual XID recovery by the transaction server.             */
/*                                                                  */
/*   The xaInfo string that is returned on the cwbXA_AddRMID call   */
/*   and the CWBXA_DLL constant should be passed in to the          */
/*   XARMCreate call.                                               */
/*                                                                  */
/*   The GetXaSwitch and the xaInfo string should be used for XID   */
/*   recovery purposes.                                             */
/*                                                                  */
/********************************************************************/

/* Prevent multiple includes */
#if !defined( _CWBXA_H_ )
  #define     _CWBXA_H_

#include <windows.h>
#include "xa.h"   // XA interface 
                  // Could be Windows, iSeries, or Linux header file that
                  // might not be ready for 64-bit: XID struct contains long's

/* Common Client Access/400 API include */
#include "cwbcosys.h"

/* Where XA interface lives */
#ifdef CWB_LINUX
  #define CWBXA_DLL "libcwbcore.so"
#else // WIN32
  #define CWBXA_DLL "cwbcore.dll"
#endif // CWB_LINUX

/* Length for an IASP database name */
#define CWBXA_DBNAME_LEN  ( 18 )
/* Length for the Transaction Manager name */
#define CWBXA_TMNAME_LEN  ( 10 )
/* Length for XA info connection string, 10 provides room for keywords */
#define CWBXA_INFO_LEN  ( CWBCO_MAX_SYS_NAME + 10 + \
                          CWBCO_MAX_USER_ID  + 10 + \
                          CWBCO_MAX_PASSWORD + 10 + \
                          CWBXA_DBNAME_LEN   + 10 + \
                          10                 + 10 + \
                          10                 + 10 + \
                          CWBXA_TMNAME_LEN   + 10 + 500 )

#ifdef __cplusplus
extern "C" {
#endif

/********************************************************************/
/*                                                                  */
/* API:                                                             */
/*   cwbXA_AddRMID                                                  */
/*                                                                  */
/* Purpose:                                                         */
/*   Associate a system object with a Resource Manager ID (RMID)    */
/*   for use with subsequent cwbXA API calls.                       */
/*                                                                  */
/* Parameters:                                                      */
/*   INT resourceManagerID - input                                  */
/*     Resource Manager ID which uniquely identifies the resource   */
/*     manager instance.  The caller must create and maintain this  */
/*     ID.                                                          */
/*                                                                  */
/*   cwbCO_SysHandle system - input                                 */
/*     Handle returned previously from cwbCO_CreateSystem() or      */
/*     cwbCO_CreateSystemLike().  It identifies the server to       */
/*     associate with the RMID. If NULL, this is a request to       */
/*     update an existing RMID's options.                           */
/*                                                                  */
/*   cwbCO_Service service - input                                  */
/*     The service to use for the connection to the server.  This   */
/*     should be either CWBCO_SERVICE_DATABASE or                   */
/*     CWBCO_SERVICE_ODBC. Ignored if system=NULL.                  */
/*                                                                  */
/*   cwbXA_addRMID_Options * pOpts - input (optional)               */
/*     Various options can be specified. Just OR the _SPECIFIED     */
/*     bits for the options that are to be used from the input      */
/*     structure. More options may be added in the future.          */
/*                                                                  */
/*     NOTE: Only CWBXA_x_SPECIFIED options are sent to the host,   */
/*     NOTE:   the rest are set to default values by the host side. */
/*     NOTE: The caller is responsible for making sure all          */
/*     NOTE:   all specified options are valid for the level of     */
/*     NOTE    host server.                                         */
/*                                                                  */
/*     - The IASP database name. Null terminated string with max    */
/*         size of CWBXA_DBNAME_LEN. Default is host configured.    */
/*     - Resource Manager Transaction timeout. In seconds, zero     */
/*         means infinite. Default is host configured.              */
/*     - Resource Manager Transaction lock timeout. In seconds.     */
/*         Default is host configured.                              */
/*     - Client Transaction Manager name. Only used in rare cases   */
/*         where host has special processing for a specific         */
/*         client transaction manager. Null terminated string with  */
/*         max size of CWBXA_TMNAME_LEN. Default is host configured.*/
/*         (This option is not yet implemented!)                    */
/*                                                                  */
/*   char * xaInformation - output (optional)                       */
/*     A buffer of CWBXA_INFO_LEN size into which is written the    */
/*     resulting XA information string. Ignored if system=NULL.     */
/*                                                                  */
/* Return Codes:                                                    */
/*  The following list shows common return values.                  */
/*   XA_OK - Successful Completion.                                 */
/*   XAER_INVAL - One of the input values is invalid, for example:  */
/*     - the resourceManagerID is already associated with a system  */
/*       objector does not exist for an update call.                */
/*     - the system object passed-in is not in a signed-on state    */
/*     - the service passed-in is not a valid value                 */
/*     - the xaInformation buffer pointer is NULL                   */
/*                                                                  */
/* Usage Notes:                                                     */
/*   The system object passed-in should already be in a signed-on   */
/*   state, because valid security information from the system      */
/*   object is needed to create the resulting XA information        */
/*   string.  The sign-on occurs as the result of a call to either  */
/*   cwbCO_Connect or cwbCO_Signon, or as the result of some other  */
/*   call that is documented as causing a sign-on or connection.    */
/*                                                                  */
/*   When you are done using the RMID/system object pair, you must  */
/*   call cwbXA_DeleteRMID, passing the same RMID you passed-in     */
/*   here, so that system resources can be freed.                   */
/*                                                                  */
/*   To indicate an update call, just pass NULL for system and the  */
/*   updated values in the options. The old options will be         */
/*   completely overwritten with this new set of options            */
/*                                                                  */
/********************************************************************/

/* Option bits */
#define CWBXA_IASPName_SPECIFIED     1
#define CWBXA_RMTimeout_SPECIFIED    2
#define CWBXA_LockTimeout_SPECIFIED  4
#define CWBXA_TMName_SPECIFIED       8
#define CWBXA_LockSharing_SPECIFIED 16

/* Option Values */
#pragma pack(1)
typedef struct _cwbXA_addRMID_Options
{
  unsigned options;                      /* which options are specified */
  char     IASPName[CWBXA_DBNAME_LEN+1]; /* IASP Database name          */
  unsigned RMTimeout;                    /* Transaction timeout         */
  unsigned LockTimeout;                  /* Transaction lock timeout    */
  char     TMName[CWBXA_TMNAME_LEN+1];   /* Transaction Manager Name    */
  /* reserved for more options...                                   */
} cwbXA_addRMID_Options, * PcwbXA_addRMID_Options;
#pragma pack()

int __cdecl
cwbXA_addRMID( int                      iRMID,     // IN
               cwbCO_SysHandle          hSys,      // IN
               cwbCO_Service            nSrv,      // IN
               cwbXA_addRMID_Options  * pOpts,     // IN (OPTIONAL)
               char *                   xaInfo ) ; // OUT

/********************************************************************/
/*                                                                  */
/* API:                                                             */
/*   cwbXA_DeleteRMID                                               */
/*                                                                  */
/* Purpose:                                                         */
/*   Removes an existing association between a Resource Manager ID  */
/*   (RMID) and a system object.                                    */
/*                                                                  */
/* Parameters:                                                      */
/*   INT resourceManagerID - input                                  */
/*     The RMID previously associated with a system object by a     */
/*     call to cwbXA_AddRMID.                                       */
/*                                                                  */
/* Return Codes:                                                    */
/*  The following list shows common return values.                  */
/*   XA_OK - Successful Completion.                                 */
/*   XAER_INVAL - The input RMID is invalid or is not currently     */
/*                associated with a system object.                  */
/*                                                                  */
/* Usage Notes:                                                     */
/*   This call should be paired with exactly one previous call to   */
/*   cwbXA_AddRMID, so that system resources can be freed.          */
/*                                                                  */
/********************************************************************/
int __cdecl
cwbXA_deleteRMID( int iRMID ) ; // IN

/********************************************************************/
/*                                                                  */
/* APIs:                                                            */
/*   cwbXA_open, cwbXA_close                                        */
/*   cwbXA_start, cwbXA_end                                         */
/*   cwbXA_rollback, cwbXA_prepare, cwbXA_commit,                   */
/*   cwbXA_recover, cwbXA_forget, cwbXA_complete                    */
/*                                                                  */
/* Purpose:                                                         */
/*   Provide Open XA interface to iSeries server databases.         */
/*   For purpose of each individual API, see the Open XA            */
/*   specification, available from www.opengroup.org at the time    */
/*   of this writing.                                               */
/*                                                                  */
/* Parameters:                                                      */
/*   See the XA Spec at www.opengroup.org                           */
/*                                                                  */
/*   NOTE: the XID struct in xa.h is not 64-bit safe, it contains   */
/*   long's. The cwbxa code will accept XID in this format for the  */
/*   API's and will automatically perform any conversion when       */
/*   sending/receiving the XID's to the iSeries.                    */
/*                                                                  */
/* Return Codes:                                                    */
/*  The following list shows common return values.                  */
/*  XA_RBBASE 100              = inclusive lower bound of the       */
/*                               rollback codes                     */
/*  XA_RBROLLBACK XA_RBBASE    = rollback was caused by an          */
/*                               unspecified reason                 */
/*  XA_RBCOMMFAIL XA_RBBASE+1  = rollback was caused by a           */
/*                               communication failure              */
/*  XA_RBDEADLOCK XA_RBBASE+2  = deadlock was detected              */
/*  XA_RBINTEGRITY XA_RBBASE+3 = condition that violates the        */
/*                               integrity of the resources was     */
/*                               detected                           */
/*  XA_RBOTHER XA_RBBASE+4     = resource manager rolled back the   */
/*                               transaction branch for a reason    */
/*                               not on this list                   */
/*  XA_RBPROTO XA_RBBASE+5     = protocol error occurred in the     */
/*                               resource manager                   */
/*  XA_RBTIMEOUT XA_RBBASE+6   = transaction branch took too long   */
/*  XA_RBTRANSIENT XA_RBBASE+7 = may retry the transaction branch   */
/*  XA_RBEND XA_RBTRANSIENT    = inclusive upper bound of the       */
/*                               rollback codes                     */
/*  XA_TWOPHASE 13             = Use two-phase commit               */
/*  XA_PROMOTED 12             = AP promoted to initiator           */
/*  XA_DEFERRED 11             = commit decision has not been made  */
/*  XA_RETRY_COMMFAIL 10       = xa_commit could not be completed   */
/*                               due to communication failure       */
/*  XA_NOMIGRATE 9             = resumption must occur where        */
/*                               suspension occurred                */
/*  XA_HEURHAZ 8               = transaction branch may have been   */
/*                               heuristically completed            */
/*  XA_HEURCOM 7               = transaction branch has been        */
/*                               heuristically committed            */
/*  XA_HEURRB 6                = transaction branch has been        */
/*                               heuristically rolled back          */
/*  XA_HEURMIX 5               = transaction branch has been        */
/*                               heuristically committed and rolled */
/*                               back                               */
/*  XA_RETRY 4                 = function returned with no effect   */
/*                               and may be re-issued               */
/*  XA_RDONLY 3                = the transaction branch was         */
/*                               read-only and has been committed   */
/*  XA_OK 0                    = normal execution                   */
/*                                                                  */
/*  XAER_ASYNC -2              = asynchronous operation already     */
/*                               outstanding                        */
/*  XAER_RMERR -3              = resource manager error occurred in */
/*                               the transaction branch             */
/*  XAER_NOTA -4               = XID is not valid                   */
/*  XAER_INVAL -5              = invalid arguments were given       */
/*  XAER_PROTO -6              = function invoked in an improper    */
/*                               context                            */
/*  XAER_RMFAIL -7             = resource manager unavailable       */
/*  XAER_DUPID -8              = XID already exists                 */
/*  XAER_OUTSIDE -9            = resource manager doing work        */
/*                               outside global transaction         */
/*                                                                  */
/********************************************************************/
int __cdecl cwbXA_open    ( char* szXAinfo                   , int iRMID , long lFlags ) ;
int __cdecl cwbXA_close   ( char* szXAinfo                   , int iRMID , long lFlags ) ;
int __cdecl cwbXA_start   ( XID* pXID                        , int iRMID , long lFlags ) ;
int __cdecl cwbXA_end     ( XID* pXID                        , int iRMID , long lFlags ) ;
int __cdecl cwbXA_rollback( XID* pXID                        , int iRMID , long lFlags ) ;
int __cdecl cwbXA_prepare ( XID* pXID                        , int iRMID , long lFlags ) ;
int __cdecl cwbXA_commit  ( XID* pXID                        , int iRMID , long lFlags ) ;
int __cdecl cwbXA_forget  ( XID* pXID                        , int iRMID , long lFlags ) ;
int __cdecl cwbXA_recover ( XID* pXIDs , long lCountAskedFor , int iRMID , long lFlags ) ;
int __cdecl cwbXA_complete( int* iHandle , int* iReturnValue , int iRMID , long lFlags ) ;

/********************************************************************/
/*                                                                  */
/* API:                                                             */
/*   GetXaSwitch                                                    */
/*                                                                  */
/* Purpose:                                                         */
/*   Provide Open XA interface to iSeries server databases.         */
/*   For purpose of each individual API, see the Open XA            */
/*   specification, available from www.opengroup.org at the time    */
/*   of this writing.                                               */
/*                                                                  */
/* Parameters:                                                      */
/*   See the XA Spec at www.opengroup.org                           */
/*                                                                  */
/* Return Codes:                                                    */
/*   XA_OK      = Success                                           */
/*   XAER_INVAL = Null pointer passed in                            */
/*                                                                  */
/********************************************************************/
/*HRESULT __cdecl GetXaSwitch( DWORD XaSwitchFlags , const xa_switch_t** ppXaSwitch ) ;*/

#ifdef __cplusplus
}
#endif

#endif /* _CWBXA_H_ */
